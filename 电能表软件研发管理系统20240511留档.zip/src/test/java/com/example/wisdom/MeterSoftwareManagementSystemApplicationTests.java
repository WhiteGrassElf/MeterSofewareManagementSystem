package com.example.wisdom;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MeterSoftwareManagementSystemApplicationTests {

    @Test
    void contextLoads() {
    }

}
